window.onload = function(){
	$("#return_left_img").click(function(){//返回上一个页面的方法
		window.history.back();
		location.reload(); 
		window.location.go(-1);
	})
}